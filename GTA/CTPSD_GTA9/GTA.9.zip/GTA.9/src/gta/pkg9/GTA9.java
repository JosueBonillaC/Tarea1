package gta.pkg9;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
// @Josue Bonilla Castro
public class GTA9 {

   
    public static void main(String[] args) {
    File archivo;
    PrintWriter escribir;
    archivo = new File ("NotasDelEstudiante.txt"); //Nombre del archivo 
    if (archivo.exists()){ //Confirmar si el archivo existe
        System.out.println("Archivo Creado");
        try { 
        archivo.createNewFile();
        } catch (IOException e) {
        }      
    }else{
         System.out.println("Archivo ya existe");
        try {
            escribir = new PrintWriter(archivo,"utf-8");
            escribir.println("Bienvenido al programa");
            Scanner n = new Scanner(System.in);//Nombre Del estudiante
            System.out.println("Ingrese el nombre del estudiante");
            String nombre = n.next();
            Scanner a = new Scanner(System.in);//Apellido Del estudiante
            System.out.println("Ingrese el apellido del estudiante");
            String apellido = a.next();
            Scanner s = new Scanner(System.in);//Seccion Del estudiante
            System.out.println("Ingrese la seccion del estudiante");
            String seccion = s.next();
            Scanner m = new Scanner(System.in);//Nombre De La Materia 
            System.out.println("Ingrese el nombre de la materia especial academica");
            String materia = m.next(); 
            Scanner r = new Scanner(System.in);//Numero de gta 
            System.out.println("Ingrese la cantidad de gta");
            int cn = r.nextInt();
            Scanner p = new Scanner(System.in);//Cantidad total de puntos 
            System.out.println("Ingrese la cantidad total de puntos");
            float puntos = p.nextFloat();
            int numero=1;
            float gta=0;
            while (numero<=cn){ //Proceso de captura de notas de la gta 
            System.out.println("Ingrese la nota de la gta"+numero);
             float g = r.nextFloat();    
             gta +=g;
             numero++;
            }
            float promedio = (gta / puntos)*100; //Formula
             String rendimiento=null;
             if (promedio<=30){ //Proceso para sacar el nivel de logro
                 rendimiento="inicial";
              }else if(promedio>30&&promedio<=60){   
                  rendimiento="Intermedio";
               }else {
                   rendimiento="Avanzado";
               }   
            //Impresion en pantalla
             escribir.println("Nombre del estudainte:"+nombre + apellido);
             System.out.println("Nombre del estudainte:"+nombre + apellido);
             escribir.println("Seccion del estudiante:"+seccion);
             System.out.println("Seccion del estudiante:"+seccion);
             escribir.println("Nombre de la materia:"+materia);
             System.out.println("Nombre de la materia:"+materia);
             escribir.println("Cantidad de Gta enviadas:"+cn);
             System.out.println("Cantidad de Gta enviadas:"+cn);
             escribir.println("Cantidad de puntos totales de todas las gta:"+puntos);
             System.out.println("Cantidad de puntos totales de todas las gta:"+puntos);
             escribir.println("Cantidad de puntos obtenidos:"+gta);
             System.out.println("Cantidad de puntos obtenidos:"+gta);
             escribir.println("La nota del estudainte es:"+promedio);
             System.out.println("La nota del estudainte es:"+promedio);
              escribir.println("La nota del estudainte es:"+rendimiento);
             System.out.println("El nivel de logro alcanzado es:"+rendimiento);
             escribir.close();
          }catch (FileNotFoundException | UnsupportedEncodingException e){
        }
      }    
   
   }
}
